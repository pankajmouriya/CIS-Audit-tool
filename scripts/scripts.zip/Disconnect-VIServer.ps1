$server=$args[0]
Disconnect-VIServer -Server $server -Force -Confirm:$false